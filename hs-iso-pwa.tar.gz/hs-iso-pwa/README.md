# HS Iso-Draw v11.3 - Vercel 배포 가이드

## 프로젝트 구조
```
hs-iso-pwa/
├── vercel.json          # Vercel 설정
├── package.json
├── public/
│   ├── index.html       # 메인 앱 (PWA)
│   ├── manifest.json    # PWA 매니페스트
│   ├── sw.js            # Service Worker (오프라인)
│   ├── icon-192.png     # 앱 아이콘
│   └── icon-512.png     # 앱 아이콘
└── api/
    └── analyze.js       # AI 중계 서버 (Serverless)
```

## 배포 방법

### 1. GitHub에 올리기
```bash
cd hs-iso-pwa
git init
git add .
git commit -m "HS Iso-Draw v11.3"
git remote add origin https://github.com/본인계정/hs-iso-draw.git
git push -u origin main
```

### 2. Vercel 연결
1. https://vercel.com 가입 (GitHub 계정으로)
2. "New Project" → GitHub 저장소 선택
3. 그대로 "Deploy" 클릭
4. 완료! https://hs-iso-draw.vercel.app 같은 URL 생성

### 3. 서버 AI 기능 설정 (API키 없는 사용자용)
1. Vercel 대시보드 → 프로젝트 → Settings → Environment Variables
2. 추가:
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-api03-...` (본인 Claude API 키)
3. Redeploy

### 4. 커스텀 도메인 (선택)
1. Vercel 대시보드 → Domains
2. 원하는 도메인 추가

## 사용 방법

### API 키가 있는 사용자
- ⚙️ 설정에서 본인 API 키 입력
- 📁 이미지 업로드 → "🤖 AI 분석 (자체 키)" → 자동 변환

### API 키가 없는 사용자
- 📁 이미지 업로드 → "🤖 AI 분석 (서버)" → 서버 경유 변환
- 서버 환경변수에 ANTHROPIC_API_KEY 설정 필요

### JSON 붙여넣기 (오프라인)
- 📋 JSON 탭 → 직접 JSON 입력 → 도면 생성

## PWA 설치 (홈화면 추가)
- Chrome: 주소창 우측 "설치" 또는 메뉴 → "홈 화면에 추가"
- Safari: 공유 → "홈 화면에 추가"

## Play Store APK 변환 (Phase 3)
- https://pwabuilder.com 에서 URL 입력 → APK 생성 가능
- 또는 Bubblewrap CLI 사용
