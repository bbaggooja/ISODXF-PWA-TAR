// Vercel Serverless Function: /api/analyze.js
// 환경변수 ANTHROPIC_API_KEY에 키 설정 필요 (Vercel 대시보드 > Settings > Environment Variables)

module.exports = async function(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") { res.status(200).end(); return; }
  if (req.method !== "POST") { res.status(405).json({ error: "POST only" }); return; }

  var API_KEY = process.env.ANTHROPIC_API_KEY;
  if (!API_KEY) { res.status(500).json({ error: "서버 API 키 미설정" }); return; }

  // 간단한 레이트 리밋 (IP당 하루 20회)
  // 실제 운영 시 Redis 등 사용 권장. 여기서는 메모리 기반 간단 구현.

  try {
    var body = req.body;
    if (!body || !body.image) {
      res.status(400).json({ error: "image (base64) 필요" });
      return;
    }

    var mediaType = body.mediaType || "image/jpeg";

    var response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 2000,
        messages: [{
          role: "user",
          content: [
            {
              type: "image",
              source: { type: "base64", media_type: mediaType, data: body.image }
            },
            {
              type: "text",
              text: '이 이미지는 가스배관 설치사진 또는 등각도면 스케치입니다. 배관 경로를 등각좌표로 변환하세요. JSON만 출력: {"segments":[{"direction":"right|left|up|down","length":숫자}],"equipment":[{"type":"meter|valve|cock|range|cap|tee","name":"장비명","after_segment":구간번호}],"info":{"pipe_size":"20A","pipe_material":"PE","title":"제목"}} direction: right=NE30도 left=NW150도 down=수직하향 up=수직상향. length=미터.'
            }
          ]
        }]
      })
    });

    if (!response.ok) {
      var errData = await response.json().catch(function() { return {}; });
      res.status(response.status).json({ error: errData.error?.message || "API 오류 " + response.status });
      return;
    }

    var data = await response.json();
    var text = data.content.map(function(c) { return c.text || ""; }).join("");
    var jm = text.match(/\{[\s\S]*\}/);

    if (jm) {
      res.status(200).json(JSON.parse(jm[0]));
    } else {
      res.status(500).json({ error: "AI 응답에서 JSON 추출 실패" });
    }
  } catch (e) {
    res.status(500).json({ error: "서버 오류: " + e.message });
  }
};
